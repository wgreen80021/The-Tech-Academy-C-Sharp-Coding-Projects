﻿using drillCars.Controllers;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace drillCars.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {


            return View();
        }
        public ActionResult GetQuote(string firstName, string lastName, string emailAddress,
                                     string dateOfBirth, string carYear, string carMake, string carModel,
                                     bool duis, int speedingTix, string coverage, string quoteAmount)
        {
            using (CarQuotesEntities db = new CarQuotesEntities())
            {
                var quoteapp = new Quote();

                quoteapp.FirstName = firstName;
                quoteapp.LastName = lastName;
                quoteapp.EmailAddress = emailAddress;
                quoteapp.DateofBirth = dateOfBirth;
                quoteapp.CarYear = carYear;
                quoteapp.CarMake = carMake.ToUpper();
                quoteapp.CarModel = carModel.ToUpper();
                quoteapp.DUIS = duis;
                quoteapp.SpeedingTix = Convert.ToInt32(speedingTix);
                quoteapp.Coverage = coverage;

                // process quote before saving : 

                decimal baseRate = 50.00m;
                var today = DateTime.Today;
                var age = today.Year - Convert.ToDateTime(quoteapp.DateofBirth).Year;
                decimal QuoteRate = baseRate;
                var YOC = Convert.ToInt32(quoteapp.CarYear);
                //var HasDUI = Convert.ToBoolean(quoteapp.DUIS);

                if (age > 100 || (age < 25 && age > 17))
                {
                    QuoteRate = QuoteRate + 25;
                }
                else if (age < 18)
                {
                    QuoteRate = QuoteRate + 100;
                }

                if (quoteapp.CarMake == "PORSCHE")
                {
                    QuoteRate = QuoteRate + 25;
                    if (quoteapp.CarModel == "911")
                    {
                        QuoteRate = QuoteRate + 25;
                    }
                }
                if (quoteapp.SpeedingTix > 0)
                {
                    QuoteRate = (QuoteRate + (quoteapp.SpeedingTix * 10));
                }

                if (quoteapp.DUIS == true)
                {
                    QuoteRate = QuoteRate + ((QuoteRate * 25 )/ 100);
                }

                if (quoteapp.Coverage == "Full Coverage")
                {
                    QuoteRate = QuoteRate + ((QuoteRate * 50) / 100);
                }


               quoteapp.QuoteAmount = Convert.ToDecimal(QuoteRate);

                //quoteapp.QuoteAmount = quoteAmount;
                db.Quotes.Add(quoteapp);
                db.SaveChanges();

                string strThankYou = "Thank you for applying " + quoteapp.FirstName + " Your Monthly Quote is : $" + quoteapp.QuoteAmount;
                ViewBag.message = strThankYou;

            }


            
            return View("~/Views/ThankYou.cshtml" );
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}