﻿
using drillCars.ViewModels;
using drillCars.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace drillCars.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin

        public ActionResult Index()
        {
            using (CarQuotesEntities db = new CarQuotesEntities())
            
   
            {


                var quoteapp = (from c in db.Quotes
                                select c).ToList();

                var appVms = new List<ApplicantVm>();
                foreach (var appvm in quoteapp)
                {

                    var quotevm = new ApplicantVm();
                    quotevm.FirstName = appvm.FirstName;
                    quotevm.LastName = appvm.LastName;
                    quotevm.EmailAddress = appvm.EmailAddress;
                    quotevm.QuoteAmount = Convert.ToDecimal(appvm.QuoteAmount);


                }
                return View(quoteapp);

            }
        }
    }
}